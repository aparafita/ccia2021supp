import sys
import json
import os

import numpy as np
import pandas as pd

from glob import glob
from utils import path

if __name__ == '__main__':
    models_folder, results_folder = sys.argv[1:3]
    cv_total = int(sys.argv[3] if len(sys.argv) > 3 else 10)

    results = []
    for f in glob(path(results_folder, '*.json')):
        filename = os.path.split(f)[-1]
        # '%.3d_%.3d.json' % (args.replication, args.cv)
        filename = filename[:filename.index('.json')]
        repl, cv = filename.split('_')
        repl, cv = int(repl), int(cv)
        
        with open(f) as f:
            j = json.load(f)
        
        j['repl'] = repl
        j['cv'] = cv
        
        with open(path(models_folder, 'graph_%.3d_%.3d.json' % (repl, cv))) as f:
            j2 = json.load(f)
            j['training_time'] = j2['training_time']
        
        results.append(j)
        
    if not results:
        print('No results')
        exit()
        
    results = pd.DataFrame(results)
    print(f'{results.shape[0]} ({results.repl.unique().shape[0]}) samples')
    
    repl_size = results.groupby('repl').size()
    
    if len(results) < cv_total:
        print(results.drop(['cv', 'repl'], 1).mean())
    else:
        results = results[results.repl.isin(repl_size.index[repl_size == cv_total])]

        time = results.training_time.groupby(results.repl).mean()
        results = results.loc[results.groupby('repl').apply(lambda g: g.val_nll.idxmin()).values]
        results = results.set_index('repl')
        results['training_time'] = time
        results = results.drop(['cv'], 1)

        for k, v in results.apply(
            lambda x: f'{x.mean()} +- {1.96 * x.std() / np.sqrt(len(x))}'
        ).items():
            print(f'{k}\t{v}')