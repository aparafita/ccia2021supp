from dcg.graph import CausalGraph

from dcg.distributional.continuous import Normal
from dcg.distributional.discrete import Bernoulli, Categorical, Poisson
from dcg.flow import NCF
from dcg.latents import LatentNormal
from dcg.modules import InputNode

def build_graph(definition):
    # This call works for both ihdp and jobs
    return CausalGraph.from_definition(
        CausalGraph.parse_definition(
            definition,
            lat=LatentNormal,
            bern=Bernoulli,
            cat=Categorical,
            pois=Poisson,
            cont=NCF,
            norm=Normal,
            input=InputNode
        ),
        node_kwargs=dict(
            t=dict(discrete=True),
            yf=dict(head_parents=['t'])
        )
    )