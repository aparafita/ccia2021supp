for repl in $(seq 443 443); do for cv in $(seq 0 9); do python3 scripts/train.py ihdp $repl $cv data/ihdp models/ihdp results/ihdp; done; done;
