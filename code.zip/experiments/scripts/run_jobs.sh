for repl in $(seq 0 9); do for cv in $(seq 0 9); do python3 scripts/train.py jobs $repl $cv data/jobs models/jobs results/jobs; done; done;
