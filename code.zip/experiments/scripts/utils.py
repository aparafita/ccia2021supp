import os.path
path = lambda *args: os.path.join(*(x2 for x in args for x2 in x.split('/')))
