import numpy as np
import pandas as pd

from utils import path


def _ihdp(path, repl):
    d = dict(np.load(path))
    
    scalars = { k: v for k, v in d.items() if v.shape == tuple() }
    x = d.pop('x')
    
    df = pd.DataFrame({
        k: v[..., repl]
        for k, v in d.items()
        if k not in scalars
    })
    
    for i in range(x.shape[1]):
        col = 'x%d' % i
        df[col] = x[:, i, repl]
        
        # Variables x[6:] are binary
        if i >= 6:
            if i == 13: # 13 contains values [1, 2] -> [0, 1]
                df[col] -= 1
                
            df[col] = df[col] > .5
        
    # return df, scalars
    return df


def _jobs(path, repl):
    d = dict(np.load(path))
    
    x = d.pop('x')
    df = pd.DataFrame({
        k: d[k][..., repl] > .5
        for k in ['t', 'yf', 'e']
    })
    
    for i in range(x.shape[1]):
        col = 'x%d' % i
        df[col] = x[:, i, repl]
        
        # Variables (2, 3, 4, 5, 13, 14, 16) are binary
        if i in (2, 3, 4, 5, 13, 14, 16):
            df[col] = df[col] > .5
        
    # return df, scalars
    return df


def _load(method, repl, data_folder, cv=None, split_sizes=None):
    train = method(path(data_folder, 'train.npz'), repl)
    test = method(path(data_folder, 'test.npz'), repl)
    
    # We need to shuffle train and test, 
    # since the experimental results appear at the end
    rs = np.random.RandomState(seed=123)
    train = train.sample(len(train), replace=False, random_state=rs)
    test = test.sample(len(test), replace=False, random_state=rs)
    
    if cv is None:
        train_size, val_size = split_sizes
        train_size = int(train_size / (train_size + val_size) * len(train))

        train, val = train[:train_size], train[train_size:]
    else:
        k, K = cv
        step = len(train) // K
        
        splits = np.arange(0, len(train), step)
        
        val = train[splits[k] : splits[k] + step]
        train = pd.concat([
            train[:splits[k]],
            train[splits[k] + step:]
        ], 0)

    return train, val, test

def ihdp(repl=0, data_folder='data/ihdp', cv=None):
    return _load(_ihdp, repl, data_folder, cv, split_sizes=(63, 27))

def jobs(repl=0, data_folder='data/jobs', cv=None):
    return _load(_jobs, repl, data_folder, cv, split_sizes=(56, 24))