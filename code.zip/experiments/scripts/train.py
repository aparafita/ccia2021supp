import json

import numpy as np
import pandas as pd
import torch

from dcg.training import get_device, train, test_nll

from datasets import ihdp, jobs
from graph import build_graph
from evaluation import IHDP_Evaluator, JobsEvaluator
from utils import path

from time import time


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    
    parser.add_argument('dataset')
    parser.add_argument('replication', type=int)
    parser.add_argument('cv', type=int)
    parser.add_argument('data_folder')
    parser.add_argument('models_folder')
    parser.add_argument('results_folder')
    
    parser.add_argument('--cv_total', dest='cv_total', type=int, default=10)
    
    parser.add_argument('--load', action='store_true', dest='load')
    parser.add_argument('--metrics', dest='metrics', type=bool, default=True)

    parser.add_argument('--batch-size', dest='bs', type=int, default=128)
    parser.add_argument('--patience', type=int, default=100)

    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--weight_decay', dest='l2', type=float, default=1e-2)
    parser.add_argument('--samples', dest='samples', type=int, default=1000)

    parser.add_argument(
        '--save-model', dest='save_model', type=bool, default=True
    )
    
    args = parser.parse_args()

    assert args.dataset.lower() in ('ihdp', 'jobs')
    assert args.cv >= 0 and args.cv < args.cv_total
    assert args.bs > 0
    assert args.patience >= 0
    
    model_path = path(args.models_folder, 'graph_%.3d_%.3d.pt' % (args.replication, args.cv))

    # Set seed for replication
    np.random.seed(123)
    torch.random.manual_seed(124)

    # Get data
    dataset = args.dataset.lower()
    if dataset == 'ihdp':
        trainX, valX, testX = ihdp(args.replication, cv=(args.cv, args.cv_total))
        columns = ['yf', 't'] + ['x%d' % i for i in range(25)]
        
        loss_f = None
    elif dataset == 'jobs':
        trainX, valX, testX = jobs(args.replication, cv=(args.cv, args.cv_total))
        columns = ['yf', 't'] + ['x%d' % i for i in range(17)]
        
        # We add weights to Jobs training. Since we include the observational, all t=0, dataset,
        # we need to make the network learn also from t=1. 
        # In this experiment, we'll treat df[e] and df[~e] equally,
        # since both will be passed to the graph as interventions.
        # This is possible because x and t are represented as InputNodes
        # and we don't care about the relationship between t and x,
        # as we don't model their structural equations.
        # In the normal case, we would train with all variables as observational in the observational dataset, 
        # and (z, y) observational and t interventional for the experimental dataset.
        w = np.clip(trainX.t.mean(), 1e-6, 1 - 1e-6)
        def to_weight(t):
            return .5 * (t / w + (1 - t) / (1 - w))
        
        loss_f = lambda batch, idx, ex_n=100, train=True: \
            graph.nll(batch, ex_n=ex_n) * to_weight(batch[:, graph.index('t')].flatten())

    # Build graph
    device = get_device() # cuda if available; otherwise cpu

    with open(path(args.data_folder, 'definition.txt')) as f:
        definition = f.read()

    graph = build_graph(definition).to(device)

    # Train
    if not args.load:
        training_start_time = time()
        train(
            graph, 
            torch.Tensor(trainX[columns].values.astype(float)), 
            torch.Tensor(valX[columns].values.astype(float)), 
            optimizer_kwargs=dict(lr=args.lr, weight_decay=args.l2),
            loss_f=loss_f, # only jobs uses this
            batch_size=args.bs, 
            patience=args.patience,
            use_tqdm=False,
        )
        training_end_time = time()
        
        with open(
            path(args.models_folder, 'graph_%.3d_%.3d.json' % (args.replication, args.cv)), 'w'
        ) as f:
            training_json = {
                'batch_size': args.bs,
                'patience': args.patience,
                'lr': args.lr,
                'weight_decay': args.l2,
                
                'training_time': training_end_time - training_start_time,
            }
            json.dump(training_json, f)

        # Save state dict
        if args.save_model:
            torch.save(graph.state_dict(), model_path)
            
    # Compute metrics
    if args.metrics:
        if args.load:
            graph.load_state_dict(torch.load(model_path))
            
        # Set seed for replication again.
        # That way, when computing metrics after training or not, 
        # it gives the same result.
        np.random.seed(123)
        torch.random.manual_seed(124)
    
        trainX = pd.concat([trainX, valX], 0)

        metrics = []

        for df in (trainX, testX):
            graph.eval()
            with torch.no_grad():
                X = torch.Tensor(df[columns].values.astype(float)).to(device)
                yf = X[:, graph.index('yf')].flatten().cpu().numpy()
                t = X[:, graph.index('t')].flatten().cpu().numpy()

                # Not using yf
                X = X.repeat(args.samples, 1) # args.samples counterfactual samples aggregated
                n = X.size(0)
                X = graph.tensor_to_dict(X)
                X.pop(graph['yf']) # don't use the factual outcome in this estimation

                X[graph['t']] = 0
                y0 = graph.sample(n, 'yf', interventions=X)\
                    .view(args.samples, -1).mean(0).cpu().numpy() # aggregate

                X[graph['t']] = 1
                y1 = graph.sample(n, 'yf', interventions=X)\
                    .view(args.samples, -1).mean(0).cpu().numpy() # aggregate

                # Using yf
                X = torch.Tensor(df[columns].values.astype(float)).to(device)

                intv = graph.tensor_to_dict(X)
                intv.pop(graph['yf'])
                intv[graph['t']] = 1 - intv[graph['t']]

                ycf = graph.counterfactual(X, 'yf', interventions=intv, ex_n=args.samples)\
                    .flatten().cpu().numpy()

            if dataset == 'ihdp':
                e = IHDP_Evaluator(df.yf, df.t, df.ycf, df.mu0, df.mu1)

                pehe = e.pehe(y1, y0)
                ate = e.abs_ate(y1, y0)

                y1 = t * yf + (1 - t) * ycf
                y0 = (1 - t) * yf + t * ycf
                
                pehe_star = e.pehe(y1, y0)
                ate_star = e.abs_ate(y1, y0)

                metrics.append({'pehe': pehe, 'ate': ate, 'pehe*': pehe_star, 'ate*': ate_star})

            elif dataset == 'jobs':
                e = JobsEvaluator(df.yf, df.t, df.e)

                e_att = e.e_att(y1, y0)
                risk = e.risk(y1, y0)

                y1 = t * yf + (1 - t) * ycf
                y0 = (1 - t) * yf + t * ycf
                e_att_star = e.e_att(y1, y0)
                risk_star = e.risk(y1, y0)

                metrics.append({'e_att': e_att, 'risk': risk, 'e_att*': e_att_star, 'risk*': risk_star})

            else:
                raise NotImplementedError()

        results = {}

        results['train_nll'] = test_nll(
            graph, torch.Tensor(trainX[columns].values.astype(float)), 'yf'
        )

        results['val_nll'] = test_nll(
            graph, torch.Tensor(valX[columns].values.astype(float)), 'yf'
        )

        results['test_nll'] = test_nll(
            graph, torch.Tensor(testX[columns].values.astype(float)), 'yf'
        )

        for split, d in zip(['train', 'test'], metrics):
            for k, v in d.items():
                results[split + '_' + k] = v

        # Save metrics
        with open(
            path(args.results_folder, '%.3d_%.3d.json' % (args.replication, args.cv)), 'w'
        ) as f:
            json.dump(results, f)
