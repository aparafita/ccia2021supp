"""
Train utilities for Deep Causal Graphs.

Includes functions:

* `get_device`: get the default torch.device (cuda if available).
* `train`: used to train graphs with early stopping.
* `plot_losses`: plot training and validation losses from a `train` session.
* `test_nll`: compute the test negative-loglikelihood of the test set.
"""


from tempfile import TemporaryFile
from collections import OrderedDict

import numpy as np
import matplotlib.pyplot as plt

from tqdm import tqdm

import torch
from torch import nn, optim

from .graph import CausalGraph


def get_device():
    """Return default cuda device if available, cpu otherwise."""
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def train(
    graph, trainX, valX, 
    train_weights=None, val_weights=None,
    ex_n=100, loss_f=None,
    post_training_f=None, post_validation_f=None,
    batch_size=32, optimizer=optim.Adam, 
    optimizer_kwargs=dict(lr=1e-3, weight_decay=1e-3),
    n_epochs=int(1e6), train_size=1., val_size=1., patience=100, 
    gradient_clipping=None,
    use_tqdm=True
):
    r"""Train CausalGraph model with (optional) early stopping.

    Can KeyboardInterrupt safely; 
    the resulting model will be the best one before the interruption.

    Args:
        graph (CausalGraph): graph to train.
        
        trainX (torch.Tensor): training dataset.
        valX (torch.Tensor): validation dataset.

        train_weights (torch.Tensor): 1d-tensor with the weights 
            for each sample in trainX. If None, uniform weighting assumed.
        val_weights (torch.Tensor): 1d-tensor with the weights 
            for each sample in valX. If None, uniform weighting assumed.

        ex_n (int): how many extra samples to sample when a node is missing
            or there are latent confounders.

        loss_f (func): loss function(batch, idx, ex_n=100, train=True).
            If None, uses graph.nll(batch, ex_n=ex_n) instead.
            Boolean parameter train indicates whether we're in training (True)
            stage or validation (False) stage.

            idx is an index tensor signaling which entries in trainX or valX
            (depending on whether graph.training is True) are contained in batch.
            Returns a tensor with the loss computed for each entry in the batch.
            
        batch_size (int or float): If float, ratio of trainX to use per batch.
            If int, batch size.
        optimizer (torch.optim.Optimizer): optimizer class to use.
        optimizer_kwargs (dict): kwargs to pass to the optimizer.

        n_epochs (int): maximum number of epochs for training.
        train_size (int or float): If float, ratio of trainX used 
            for a whole epoch. If int, number of samples in trainX 
            used each epoch (taken randomly).
        val_size (int or float): If float, ratio of valX used 
            for a whole validation step. If int, number of samples in valX 
            used each step (taken randomly).
        patience (int): maximum number of epochs with no improvement
            in validation loss before stopping. 
            To avoid using early stopping, set to 0.

        use_tqdm (bool): whether to use tqdm to inform of training progress.

    Returns:
        train_losses: list with entries (float(epoch), loss).
        val_losses: list with entries (epoch, loss).

    The results of this function can be passed to `plot_losses` directly.
    """
    
    assert isinstance(graph, CausalGraph)

    if isinstance(batch_size, float):
        assert 0. < batch_size and batch_size <= 1.
        batch_size = int(batch_size * len(trainX))

    if isinstance(train_size, float):
        assert 0. < train_size and train_size <= 1.
        train_size = int(train_size * len(trainX))
    else:
        train_size = min(len(trainX), train_size)

    if isinstance(val_size, float):
        assert 0. < val_size and val_size <= 1.
        val_size = int(val_size * len(valX))
    else:
        val_size = min(len(valX), val_size)

    optimizer = optimizer(graph.parameters(), **optimizer_kwargs)

    train_losses, val_losses = [], []
    
    val_loss = np.inf
    best_loss = np.inf
    best_epoch = 0
    best_model = None

    if loss_f is None:
        loss_f = lambda batch, idx, ex_n=100, train=True: \
            graph.nll(batch, ex_n=ex_n)

    best_model = TemporaryFile()

    try:
        if use_tqdm:
            tq = tqdm(n_epochs)

        for epoch in range(1, n_epochs + 1):
            # Train
            graph.train()
            X = trainX
            idx = torch.randperm(len(X), device=X.device)[:train_size]
            for n in range(0, train_size, batch_size):
                if train_size - n == 1: continue
                subidx = idx[n:n + batch_size]
                batch = X[subidx].to(graph.device)

                loss = loss_f(batch, subidx, ex_n=ex_n, train=True)
                if train_weights is not None:
                    w = train_weights[subidx]
                    w = w / w.sum()
                    w = w.to(graph.device)

                    loss = (loss * w).sum()
                else:
                    loss = loss.mean()

                assert not torch.isnan(loss) and not torch.isinf(loss)
                
                # Pytorch recipe: zero_grad - backward - step
                optimizer.zero_grad()
                loss.backward()

                # Gradient clipping
                if gradient_clipping is not None:
                    assert gradient_clipping > 0
                    nn.utils.clip_grad_norm_(
                        graph.parameters(), 
                        gradient_clipping
                    )

                optimizer.step()
                
                train_losses.append((epoch + n / train_size, loss.item()))
                
                if use_tqdm:
                    tq.set_postfix(OrderedDict(
                        epoch_progress='%.3d%%' % (n / train_size * 100),
                        train_loss='%+.3e' % loss.item(), 
                        last_val_loss='%+.3e' % val_loss, 
                        best_epoch=best_epoch, 
                        best_loss='%+.3e' % best_loss
                    ))

                if post_training_f is not None:
                    post_training_f(batch, subidx)
            
            # Validation
            graph.eval()
            X = valX
            idx = torch.randperm(len(X), device=X.device)[:val_size]
            
            # Normalize w by the filtered ws, but don't filter the whole w
            # since we'll access it with the whole index.
            if val_weights is not None:
                w_val = (val_weights / val_weights[idx].sum()).to(graph.device)

            with torch.no_grad(): # won't accumulate info about gradient
                val_loss = 0.
                for n in range(0, val_size, batch_size):
                    subidx = idx[n:n + batch_size]
                    batch = X[subidx].to(graph.device)

                    val_loss_t = loss_f(batch, subidx, ex_n=ex_n, train=False)

                    if val_weights is not None:
                        w = w_val[subidx]
                        val_loss += (val_loss_t * w).sum().item()
                    else:
                        val_loss += val_loss_t.sum().item() / val_size

                val_losses.append((epoch, val_loss))

                if post_validation_f is not None:
                    post_validation_f()

            assert not np.isnan(val_loss)# and not np.isinf(val_loss)

            # Early stopping
            if best_loss > val_loss:
                best_loss = val_loss
                best_epoch = epoch
                
                best_model.seek(0)
                torch.save(graph.state_dict(), best_model)
                
            if use_tqdm:
                tq.update()
                tq.set_postfix(OrderedDict(
                    epoch_progress='100%',
                    train_loss='%+.3e' % loss.item(), 
                    last_val_loss='%+.3e' % val_loss, 
                    best_epoch=best_epoch, 
                    best_loss='%+.3e' % best_loss
                ))

            if patience and epoch - best_epoch >= patience:
                break

    except KeyboardInterrupt:
        print('Interrupted at epoch', epoch)
        pass # halt training without losing everything

    finally:
        if use_tqdm:
            tq.close()

    # Load best model before exiting
    best_model.seek(0)
    graph.load_state_dict(torch.load(best_model))
    best_model.close()

    graph.eval() # pass to eval mode before returning

    return train_losses, val_losses


def plot_losses(train_losses, val_losses, cellsize=(6, 4)):
    """Plot train and validation losses from a `train` call.

    Args:
        train_losses (list): (epoch, loss) pairs to plot for training.
        val_losses (list): (epoch, loss) pairs to plot for validation.
        cellsize (tuple): (width, height) for each cell in the plot.
    """

    best_epoch, best_loss = min(val_losses, key=lambda pair: pair[1])

    w, h = cellsize
    fig, axes = plt.subplots(1, 2, figsize=(w * 2, h * 1))

    axes[0].set_title('train_loss')
    axes[0].plot(*np.array(train_losses).T)

    axes[1].set_title('val_loss')
    axes[1].plot(*np.array(val_losses).T)
    axes[1].axvline(best_epoch, ls='dashed', color='gray')


def test_nll(graph, testX, target_node=None, weights=None, ex_n=100, batch_size=32):
    """Compute test nll using batches.

    Args:
        graph (CausalGraph): graph to train.
        testX (torch.Tensor): test dataset.
        target_node (str): node to compute the nll of.
        weights (torch.Tensor): weights to compute the aggregate of nll.
            If None, assumes uniform weighting.
        ex_n (int): how many extra samples to sample when a node is missing
            or there are latent confounders.
        batch_size (int or float): if float, ratio of testX to use per batch.
            If int, batch size.
    """

    assert isinstance(graph, CausalGraph)

    if isinstance(batch_size, float):
        assert 0. < batch_size and batch_size <= 1.
        batch_size = int(batch_size * len(textX))

    if weights is not None:
        weights = (weights / weights.sum()).to(graph.device)

    graph.eval()
    with torch.no_grad(): # won't accumulate info about gradient
        loss = 0.
        for n in range(0, len(testX), batch_size):
            idx = torch.arange(n, min(n + batch_size, len(testX)))

            batch = testX[idx].to(graph.device)
            batch_loss = graph.nll(batch, target_node=target_node, ex_n=ex_n)

            if weights is not None:
                loss += (batch_loss * weights[idx]).sum().item()
            else:
                loss += batch_loss.sum().item() / testX.size(0)

    return loss