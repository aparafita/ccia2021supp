"""
Provides miscellaneous utility functions.
"""

import numpy as np
import torch


def log_sum_exp_trick(x, log_w=None, dim=-1, keepdim=False):
    r"""Computes `log(sum(w * exp(x), dim=dim, keepdim=keepdim))` safely.
    
    Uses the logsumexp trick for the computation of this quantity.

    Args:
        x (torch.Tensor): input tensor.
        log_w (torch.Tensor): logarithm of weights to apply. 
            If None, defaults to 0 (all weights 1).
            Must have same shape as x.
        dim (int): which dimension to aggregate.
        keepdim (bool): whether to preserve the aggregated dimension.
    """

    if log_w is None:
        log_w = torch.zeros_like(x)

    x = log_w + x # add log_w here so it affects M
    M = x.max(dim=dim, keepdim=True).values

    x = torch.log(torch.exp(x - M).sum(dim=dim, keepdim=True)) + M
    
    if not keepdim:
        x = x.squeeze(dim=dim)

    return x


def log_mean_exp_trick(x, dim=-1, keepdim=False):
    """Computes `log(mean(exp(x), dim=dim, keepdim=keepdim))` safely.

    Uses the logsumexp trick for the computation of this quantity.

    Args:
        x (torch.Tensor): input tensor.
        dim (int): which dimension to aggregate.
        keepdim (bool): whether to preserve the aggregated dimension.
    """
    N = x.size(dim)

    return log_sum_exp_trick(x, dim=dim, keepdim=keepdim) - np.log(N)


def topological_sort(nodes, parents):
    r"""Return the given nodes in topological order.

    Nodes will be sorted in topological order and, secondly, if possible, 
    in their own order defined by \_\_lt\_\_ or \_\_gt\_\_.

    Args:
        nodes (list): list of nodes to sort. Each node must be hashable.
        parents (dict): dict { node: parents } with each node's parents.
    """
    
    n = len(nodes)
    nodes = set(nodes)
    assert len(nodes) == n # no duplicates
    
    # Don't mutate the outside variables -> copy parents
    parents = { node: set(parents) for node, parents in parents.items() } 

    # Any parent that is not in nodes will be ignored
    for node, ps in parents.items():
        for p in list(ps): # we'll modify ps, so copy the iterator
            if p not in nodes:
                ps.remove(p) # these nodes will not be considered

    def is_sortable(obj):
        # https://stackoverflow.com/questions/19614260/
        # check-if-an-object-is-order-able-in-python
        cls = obj.__class__

        return cls.__lt__ != object.__lt__ or \
               cls.__gt__ != object.__gt__

    sort = []
    while parents:
        # Which nodes do not have parents at this point?
        consider = { 
            node
            for node, parents in parents.items()
            if not parents
        }

        # There should be at least one; otherwise, there's a loop
        if not consider:
            raise ValueError("Topological sorting of a cyclic graph.")

        # Now, secondary ordering, if possible:
        if all(is_sortable(c) for c in consider):
            consider = sorted(consider)
        else:
            consider = list(consider)

        # Add consider to the sorted nodes list
        sort += consider

        # Finally, update parents to exclude the previously added nodes
        for node in consider:
            for node2, parents2 in parents.items():
                if node in parents2:
                    parents2.remove(node)

            parents.pop(node)

    return sort