"""
Contains `CausalGraph`, with all utilities for graph-related operations. 
"""

from copy import copy, deepcopy

import torch
from torch import nn

from .node import CausalNode
from .utils import topological_sort, log_mean_exp_trick


class CausalGraph(nn.Module):
    """
    Provides utilities for easy creation of graphs and their nodes.
    Provides utilities for sampling, nll computation and counterfactual queries.
    """
    
    # Construction methods:

    def __init__(self, nodes):
        """
        Args:
            nodes (list): list of nodes defining the graph.

        Note that CausalGraph only works for DAGs. 
        Additionally, all nodes must have unique names.
        """

        super().__init__()

        self.nodes = nn.ModuleList(nodes)

        parents = { node: node.parents for node in nodes }
        self._nodes = topological_sort(self.nodes, parents)

        self._all_nodes = [
            subnode 
            for node in self._nodes 
            for subnode in node 
        ]

        assert len({node.name for node in self._all_nodes}) == \
            len(self._all_nodes), 'Node names must be unique'

        self.device = torch.device('cpu') # start initialized with cpu

    @staticmethod
    def parse_definition(definition, **cls_dict):
        """Parse a graph definition for use in from_definition.

        A graph definition is a list of 4-tuples:
            `(node_name, node_class, node_dim, node_parents)`
        where:

        * node_name (str): name of the node. Must not contain '.'
            and must be unique across the whole definition.
        * node_class (str or CausalNode class): which CausalNode class
            to assign to this node. If str, the method looks in **cls_dict
            for the corresponding class.
        * node_dim (int): dimension of the node.
        * node_parents (tuple of str): which nodes (indexed by their name)
            are this node's parents.

        A graph definition can also be stated as a multi-line str 
        in the following format:
        ```
            node_name1 node_class node_dim parent1 parent2
            node_name2 ...
        ```

        Example:
        ```
            u latent_normal 1
            x normal 1 u
            y categorical 2 u
        ```

        Args:
            definition: str or list of 4-tuples with the graph definition.
            **cls_dict (class): 
                use keyword arguments directly to relate
                class aliases to their CausalNode classes.
                These will be packed in a dict inside the method.

        The result of this function can be passed to 
        `CausalGraph.from_definition` directly to create the graph.

        Call example:
        ```python
        from dcg import latents, distributional

        definition = CausalGraph.from_definition(
            '''
            u latent_normal 1
            x normal 1 u
            y categorical 2 u
            '''.
            latent_normal=latents.Normal,
            normal=distributional.continuous.Normal,
            categorical=distributional.discrete.Categorical
        )
        ```
        """

        if isinstance(definition, str):
            definition = [
                [t[0], t[1], t[2], t[3:]]

                for t in (
                    [ term.strip() for term in line.strip().split(' ') ]
                    for line in definition.split('\n')
                    if line.strip()
                )
            ]

        for line in definition:
            _, cls, dim, _ = line
            
            if isinstance(cls, str):
                line[1] = cls_dict[cls]

            if isinstance(dim, str):
                line[2] = int(dim)

        return definition

    @classmethod
    def from_definition(
        cls, definition, node_kwargs=None, **kwargs
    ):
        """Create a CausalGraph from a list of tuples (name, cls, dim, parents).

        You can use `CausalGraph.parse_definition` to create a graph definition.

        Args:
            node_kwargs (dict or None): dictionary { node_name: kwargs }
                used to pass keyword arguments as **kwargs 
                to the node with the corresponding node_name. 
            **kwargs: kwargs passed as **kwargs to every node's constructor.
                Note that node_kwargs overrides any keyword defined here.
        """
        
        # Assert no repetitions in naming
        node_names = list(map(lambda t: t[0], definition))
        assert len(set(node_names)) == len(node_names), \
            'Node names must be unique'

        # Order definition by topological order (we need it for Node creation)
        original_order = [ line[0] for line in definition ]
        definition_d = { line[0]: line for line in definition }

        parents = { line[0]: set(line[3]) for line in definition_d.values() }
        new_order = topological_sort(original_order, parents)

        # Reorder definition by topological ordering defined by new_order
        definition = [ definition_d[name] for name in new_order ]

        # Create final node_kwargs dicts
        node_kwargs = deepcopy(node_kwargs or {})
        for name, node_cls, dim, parents in definition:
            if name in node_kwargs:
                assert isinstance(node_kwargs[name], dict), name
            else:
                node_kwargs[name] = {}

            node_kwargs[name].update({ 
                k: v
                for k, v in kwargs.items()
                if k not in node_kwargs[name]
            })

        # Now, create nodes in topological order
        d = {}

        for name, node_cls, dim, parents in definition:
            parents = tuple(d[parent] for parent in parents)
            d[name] = node_cls(name, *parents, dim=dim, **node_kwargs[name])

        # Finally, reorder nodes by the original ordering
        nodes = [ d[name] for name in original_order ]

        return cls(nodes)

    def replace(self, original, new_node):
        """Replace original node by new_node.
        
        Adjusts parents and every relevant attribute in the node and in the graph.
        """
        original = self[original] # in case it's an indexer

        def replace(l):
            if isinstance(l, tuple):
                i = l.index(original)
                l = l[:i] + (new_node,) + l[i+1:]
            else:
                # if it's modulelist, we need it as tuple for .index
                i = tuple(l).index(original) 
                l[i] = new_node

            return l

        for node in self._all_nodes:
            if original in node.parents:
                node.parents = replace(node.parents)
                node._parents = replace(node._parents)

        replace(self.nodes)
        replace(self._nodes)

        self._all_nodes = [
            subnode 
            for node in self._nodes 
            for subnode in node 
        ]

        new_node.to(self.device)
        
        return self

    # Convenience attributes and methods
    def ancestors(self, node, all=False, visited=None):
        """Iterator that yields node and all its ancestors.

        Args:
            node (CausalNode): node to get its ancestors from.
            all (bool): whether to also yield latent private nodes or not.
        """
        root = visited is None
        if root:
            visited = set()
            
        visited.add(node)
            
        for parent in (node.parents if not all else node._parents):
            if parent not in visited:
                for _ in self.ancestors(parent, all=all, visited=visited):
                    pass
               
        if root:
            for node in visited:
                yield node

    def descendants(self, node, all=False):
        """Iterator that yields node and all its descendants.

        Args:
            node (CausalNode): node to get its descendants from.
            all (bool): whether to also yield latent private nodes or not.
        """

        assert node in self._all_nodes, node

        for descendant in (self.nodes if not all else self._all_nodes):
            if node in self.ancestors(descendant, all=all):
                yield descendant

    @property
    def node_names(self):
        """Return the list of node names."""
        return [ node.name for node in self.nodes ]

    @property
    def observable_nodes(self):
        """Return the list of observable nodes."""
        return [ node for node in self.nodes if not node.latent ]

    @property
    def latent_nodes(self):
        """Return the list of latent nodes."""
        return [ node for node in self.nodes if node.latent ]

    @property
    def trainable_nodes(self):
        """Return the list of (all) trainable nodes."""
        return [ 
            node 

            for node in self._all_nodes 
            if node.trainable
        ]

    @property
    def dim(self):
        """Reutrn the total observable dimension of the graph."""
        return sum(node.dim for node in self.observable_nodes)
    
    def index(self, key):
        """Return a `slice` with the tensor columns related with this node."""
        target_node = self[key] # if node is str, replaces by node
        assert target_node in self.nodes and not target_node.latent, target_node
        # note that latents do not have an index

        i = 0
        for node in self.observable_nodes:
            j = i + node.dim
            if target_node == node:
                return slice(i, j)
            else:
                i = j

        raise KeyError(key)

    def tensor_to_dict(self, t):
        """Transform a tensor with values for all observable nodes in the graph
        to a dict { node: value }.
        """

        assert len(t.shape) == 2 and t.size(1) == self.dim, (t.shape, self.dim)

        d = { 
            node: t[:, self.index(node)]
            for node in self.observable_nodes 
        }

        # Change all dtypes to float and moves to device
        d = self._preprocess_dict(d, t.size(0))

        return d

    def dict_to_tensor(self, d):
        """Transform a dict { node: value } into a tensor."""
        d = self._preprocess_dict(d)

        return torch.cat([
            d[node]

            for node in self.observable_nodes
            # if node in d # should contain all observable nodes
        ], dim=1)

    def _preprocess_dict(self, d, n=None):
        """Preprocess dict { node: value } for use in internal functions.

        This function transforms any kind of data into floats 
        (so that you can pass even bools as node value's)
        and non-tensors into tensors,
        shaping them correctly and even broadcasting samples if necessary. 

        If n is given, broadcasts all size(0) to that n. 
        If None, n becomes the maximum size(0) in d.
        """

        def to_tensor(v, node):
            # Redimension values with only one dim so they have 2.
            if not isinstance(v, torch.Tensor):
                if isinstance(v, (bool, int, float)):
                    v = [v]
                    
                v = torch.Tensor(v)

            while len(v.shape) < 2:
                assert node.dim == 1 # only allowed for 1-dimensional nodes
                v = v.unsqueeze(1 if len(v.shape) > 0 else 0)

            assert len(v.shape) == 2

            # Change dtype and move to device
            v = v.float().to(self.device)

            return v

        # Note that this (shallow-)copies the dict, as intended
        d = { 
            self[node]: to_tensor(v, self[node]) # also node str -> Node
            for node, v in d.items() 
        }

        if n is None: # n = max(size(0))
            n = max(v.size(0) for v in d.values())

        # Need to be sure that we can broadcast (size(0) divisor of n)
        assert all(not n % v.size(0) for v in d.values()), \
            f'Not all values in d match with size {n}'

        # Broadcast
        d = { node: v.repeat(n // v.size(0), 1) for node, v in d.items() }

        return d

    def map(self, f, filter=None, all=False):
        """Call f(node) for all nodes in graph.

        Args:
            f (function): function(node) to call for each node.
            filter (function): function(node) that returns 
                whether node should be called. If None, no filter is applied.
            all (bool): whether to also call private subnodes.
        """

        for node in self.nodes if not all else self._all_nodes:
            if filter is None or filter(node):
                f(node)

    def warm_start(self, x):
        """Call warm_start to all nodes with their given value.

        Args:
            x: tensor or dict with all observable values,
                that will be passed to each corresponding node.
        """
        if isinstance(x, torch.Tensor):
            d = self.tensor_to_dict(x)
        else:
            assert isinstance(x, dict)
            d = self._preprocess_dict(x)

        for node, v in d.items():
            node.warm_start(v)

        return self


    # Magic methods (iterability and key-access)
    def __iter__(self):
        # Note that we iter through the original ordering of the nodes.
        return iter(self.nodes)

    def __len__(self):
        return len(self.nodes) # number of user-defined nodes (not private)

    def __getitem__(self, key):
        """Look for node in the graph, indexed by key, and return it.
        
        Depending on the type of key, the result differs:
            * `str`: node with that name.
            * `int`: node in that position in the original order.
            * `slice`: list of nodes that match the slice.
            * `CausalNode`: returns the same node, if it belongs to the graph.
                Otherwise, raises a KeyError. This is used to transform 
                a name str into a node, even when you don't know 
                if your key is a str or the node you want directly.
        """

        if isinstance(key, str): # index by name
            for node in self._all_nodes:
                if node.name == key:
                    return node
            else:
                raise KeyError(key)
        elif isinstance(key, (int, slice)): # index by position in original ordering
            return self.nodes[key]
        else:
            # it should be a node that's contained in the graph
            if key in self._all_nodes:
                return key
            else:
                raise KeyError(key)

    # Override nn.Module to, cpu, cuda
    def _update_device(self, device):
        self.device = device

        for node in self.nodes:
            node._update_device(device)

        return self

    def to(self, device):
        """Move all parameters and buffers to the specified device.

        Also updates `self.device`.
        """
        self._update_device(device)
        
        return super().to(device)

    def cpu(self):
        return self.to(torch.device('cpu'))

    def cuda(self):
        return self.to(torch.device('cuda'))


    # Basic operations
    def sample(
        self, 
        n=1, target_node=None, 
        interventions=None, return_all=False
    ):
        """Sample from graph.

        Args:
            n (int): how many samples to sample.
            target_node (str or CausalNode): 
                if not None, just sample ancestors of target_node 
                and return only its value.
            interventions (dict): what interventions to apply, if any.
                Dict { node: value } with the constant value to apply 
                to each of the n samples. You can pass python scalar values,
                even booleans, or single dim tensors,
                and they will be transformed and broadcasted to all n samples.
            return_all (bool): whether to return a dict with values 
                for every node, including latents.

        Returns:
            t: tensor (n, graph.dim) with samples for all observable nodes.
                This will be returned in both cases of `return_all`.
            d: dict { node: value} for all nodes, including latents,
                only if `return_all` is True. The result will then be `(t, d)`.
        """
        assert isinstance(n, int) and n >= 1

        if target_node is not None:
            target_node = self[target_node] # transform str to Node
            ancestors = list(self.ancestors(target_node, all=True))

        # Prepare interventions
        assert isinstance(interventions, dict) or interventions is None
        interventions = self._preprocess_dict(interventions or {}, n=n)

        d = {} # this will contain each node's samples

        for node in self._all_nodes: # in topological order, all nodes (ex)
            if target_node is not None and node not in ancestors:
                continue # don't sample non-ancestors of a target node

            if node in interventions: # already sampled, just take its value
                d[node] = interventions[node]
            else: # sample using its parents values (including ex nodes)
                d[node] = node.sample(n, *(d[p] for p in node._parents))

        # Sampling is node, transform to tensor
        if target_node is None:
            t = self.dict_to_tensor(d) # transform the whole dict into a tensor
            # Note that this does only include observable nodes!
        else:
            t = d[target_node] # just get the tensor for the target_node

        if return_all:
            return t, d
        else:
            return t

    def _preprocess_y(self, y):
        """Tranform y into dict, ensures that sizes match and return (y, n).

        Used by nll and counterfactual.
        """

        if isinstance(y, torch.Tensor):
            assert y.device.type == self.device.type
            n = y.size(0)
            y = self.tensor_to_dict(y)
        else:
            assert isinstance(y, dict)
            y = self._preprocess_dict(y)
            n = max(v.size(0) for v in y.values())
            # Note that each node's tensor may have less than n samples.
            # This is no problem, since node._process_parents 
            # already does the broadcasting.

        y = copy(y) # make a copy of the dict

        return y, n

    def nll(
        self, y, target_node=None, interventions=None, 
        ex_n=100, agg=True, agg_missing=True
    ):
        r"""Compute the Negative-LogLikelihood of a sample y.
        
        Args:
            y: samples to compute nll.
                If y is a Tensor, it must include **all** observable nodes.
                If it is a dict {node: value}, it may contain 
                all or some observable nodes, and also some latent nodes.
            target_node (CausalNode): if not None, only compute nll
                for that node. The result will be a single tensor 
                with just the node's nll.
            interventions (dict): what interventions to apply, if any.
                Dict { node: value } with the constant value to apply 
                to each of the n samples. You can pass python scalar values,
                even booleans, or single dim tensors,
                and they will be transformed and broadcasted to all n samples.
                Note that intervened nodes won't sum their nll values,
                as their probability is 1.
            ex_n (int): how many samples to create per y sample
                if the total law of probability is required.
            agg (bool): whether to aggregate all node's nlls in a single tensor
                or just return a dict with each individual nll.
            agg_missing (bool): whether to aggregate nll's ex_n samples
                when some samples are missing.

        Note that if any public node is not specified 
        (except for exogenous noise signals),
        this method will use the total law of probability
        to sample values for the non-specified nodes, 
        compute the corresponding nll of the specified nodes
        and aggregate those with `dcg.utils.log_mean_exp_trick`.

        $$f(X) = \mathbb{E}_{\mathcal{V} - X}[ f(X \mid \mathcal{V} - X) ]$$
        """

        y, n = self._preprocess_y(y) # note that this copies y
        original_n = n

        if target_node is not None:
            target_node = self[target_node] # transform str to node
            # Identify target_node's ancestors (including ex noises).
            # We will sample those (if they're not specified)
            # and then compute nll with that.
            ancestors = list(self.ancestors(target_node, all=True))

        # Prepare interventions
        assert isinstance(interventions, dict) or interventions is None
        interventions = self._preprocess_dict(interventions or {}, n=n)

        for node, t in interventions.items():
            assert target_node is None or target_node != node
            y[node] = t # override value

        # If any public node is not specified (included in y),
        # we will sample them ex_n times per original sample.
        # To do that, first broadcast y to ex_n more times
        # so we can aggregate them later.

        # A node is "missing" if it can't be defined from y or its parents.
        # Note that since each function in the SCM is deterministic 
        # given all parents, having all of a node's parents 
        # (including ex_nodes) in y means that the node itself 
        # is also specified (we just have to "sample" it).

        # Are there any missing nodes? Sample them
        missing = []
        for node in self._nodes: # topological order, only public nodes
            # If we have a target_node, we're only concerned with its ancestors
            if target_node is not None and node not in ancestors:
                continue

            if node not in y: # is it missing?
                # If we find all its parents (and ex_noise) in y, it is not
                if not node._parents or any(p not in y for p in node._parents):
                    if not missing: # if we didn't have missing before
                        # This means we have truly missing nodes
                        # We need to broadcast to n * ex_n
                        n *= ex_n
                        ex_n = 1

                        # Broadcast what we have in y
                        y = { 
                            k: v.repeat(n // v.size(0), 1) 
                            for k, v in y.items() 
                        }

                    # And then add it to missing so we know there are missings
                    missing.append(node)

                # Finally, sample from the node
                y[node] = node.sample(
                    n, *(y.get(parent) for parent in node._parents),
                )

            # For any missing or not missing node, check its shape
            assert node in y and y[node].shape == (n, node.dim), y[node].shape

        # Now, compute nll for each node
        nll = {}
        for node in self._all_nodes: # this time we go through all nodes
            # If we have a target_node, we're only concerned with its ancestors
            if target_node is not None and node not in ancestors:
                continue

            if (
                not node.latent and # only compute nll of observables
                node not in missing and # and only if we have their value
                node not in interventions and # and only if it's not intervened
                target_node in (None, node) # and if there is a target node, 
                # only compute nll for it
            ):
                nll_node = node.nll(
                    y[node], 
                    *(y.get(parent) for parent in node._parents),
                )

                # Check that we didn't diverge
                assert (
                    not torch.isinf(nll_node).any() and 
                    not torch.isnan(nll_node).any()
                ), f'Divergence in nll: {node}'

                # Check that its shape matches
                assert nll_node.shape == (n,), (node, nll_node.shape)

                # Finally, save it in the dict
                nll[node] = nll_node

        # What to return?
        if target_node is not None:
            nll = nll[target_node]
        elif agg:
            nll = sum(nll.values()) # sums tensors together, not samples
        # else, return the whole dict

        # If there were missings, aggregate them now
        if missing and agg_missing:
            if isinstance(nll, dict):
                nll = {
                    node: -log_mean_exp_trick(-nll.view(-1, original_n), dim=0)
                    for node, nll in nll.items()
                }
            else:
                nll = -log_mean_exp_trick(-nll.view(-1, original_n), dim=0)

        return nll

    def counterfactual(
        self, y, target_node=None, interventions=None, ex_n=100, agg=True
    ):
        """Counterfactual estimation.

        Computes counterfactual samples from y and interventions.
        If there are any missing public values, or a node is not ex_invertible,
        computes ex_n of them for each y sample.

        If agg is True, these extra samples are aggregated and
        the counterfactual expected value for each variable in the graph
        is returned in a single tensor.

        Otherwise, a tensor (ex_n, n, graph.dim) is returned with all samples.
        This can be used for the expectancy of functions 
        of the graph's counterfactual samples.

        Args:
            y: torch.Tensor or dict with observed samples.
            interventions (dict): intervention values.
            ex_n (int): how many extra samples to take per y sample, if needed.
            agg (bool): whether to aggregate extra samples.
                Note that the format of the return depends on this value.

        Returns:
            `y`: 
                tensor of shape (n, graph.dim), only if agg=True.
            `(y, w)`:
                Only if agg=False.
                y is a tensor of shape (ex_n, n, graph.dim).
                w is a tensor of shape (ex_n, n, graph.dim)
                    or of no shape (1, if there weren't extra samples).

        Use agg=False if you want to compute a function of the counterfactuals.
        Then, aggregate each result like this:
            ```python
            z = (f(y) * w).sum(dim=0)
            ```
        """

        if target_node is not None:
            target_node = self[target_node]

        y, n = self._preprocess_y(y)
        original_n = n

        # Process interventions
        assert interventions is None or isinstance(interventions, dict)
        interventions = self._preprocess_dict(interventions or {}, n=n)

        def broadcast(d): # broadcast inplace
            for k, v in d.items():
                d[k] = v.repeat(n // v.size(0), 1)

        # Any missing nodes? Look in `nll` for an explanation.
        # Also, if an observed node isn't ex_invertible 
        # and its ex_noise isn't specified, broadcast too.
        missing = []
        broadcasted = False
        for node in self._nodes: # topological order, only public nodes
            if node not in y: # is it missing?
                # If we find all its parents (and ex_noise) in y, it is not
                if not node._parents or any(p not in y for p in node._parents):
                    if not broadcasted:
                        # We need to broadcast to n * ex_n
                        n *= ex_n
                        ex_n = 1

                        broadcast(y)
                        broadcast(interventions)

                        broadcasted = True

                    missing.append(node)

                # Finally, sample from the node
                y[node] = node.sample(
                    n, *(y.get(parent) for parent in node._parents),
                )
            else:
                # We have y, but is the node ex_invertible?
                if not broadcasted and not node._ex_invertible():
                    # We need to broadcast to n * ex_n
                    n *= ex_n
                    ex_n = 1

                    broadcast(y)
                    broadcast(interventions)

                    broadcasted = True

            # In any case, check its shape
            assert node in y and y[node].shape == (n, node.dim), y[node].shape

        # Also check shapes for interventions
        for node, v in interventions.items():
            assert v.shape == (n, node.dim), (node, v.shape)

        # Start processing
        
        # Abduction
        ex_noise = {}

        # Any non-descendant of an intervened node will not change its value.
        # Hence, consider them as if they were intervened.
        # Also, if we have a target node, any non-ascendant of the target node
        # won't matter for the value of target_node.
        descendants = {
            desc
            for node in interventions.keys()
            for desc in self.descendants(node)
            if target_node is None or target_node in self.descendants(desc)
        }

        for node in self._nodes:
            if node not in descendants:
                interventions[node] = y[node]
                ex_noise[node] = tuple()

        # Next, abduct descendants
        # This will only affect ex_noises of non-missing nodes.
        # The rest of the missing values will be sampled normally
        # and taken into account later for importance sampling.
        w = torch.zeros(n, device=self.device)
        for node in self._nodes:
            assert node in y, node

            if node not in interventions: # it it's intervened, there's no use
                if node.latent: 
                    # Latents have no ex_noise
                    # Use their sampled value as an intervention
                    interventions[node] = y[node]
                    ex_noise[node] = tuple() # no ex_noise
                else:
                    # Observable nodes do have ex_noise, so abduct
                    ex_noise[node] = node.abduct(
                        y[node], *(y[p] for p in node.parents), 
                    )

                assert isinstance(ex_noise[node], (tuple, list)), \
                    'abduct should return tuple of ex_noises (%s)' % node

                if broadcasted and node not in missing:
                    w += node.nll(
                        y[node], 
                        *(y[p] for p in node.parents), 
                        *ex_noise[node], 
                    )
                
        # Sample in the intervened model
        for node in self._nodes:
            if node not in interventions:
                from .flow import NCF
                if isinstance(node, NCF):
                    interventions[node] = node.sample(
                        n, 
                        *(interventions[p] for p in node.parents), 
                        *ex_noise[node],
                        inv_init=y[node],
                    )
                else:
                    interventions[node] = node.sample(
                        n, 
                        *(interventions[p] for p in node.parents), 
                        *ex_noise[node]
                    )
                
        # Transform to tensor
        if target_node is None:
            y = self.dict_to_tensor(interventions)
        else:
            y = interventions[target_node]

        if broadcasted:
            y = y.view(-1, original_n, y.size(-1))

            w = torch.softmax(-w.view(-1, original_n), dim=0)
            w = w.unsqueeze(2) # resulting shape (ex_n, n, graph.dim)

            if agg:
                y = (y * w).sum(dim=0)
                return y
            else:
                return y, w
        else:
            if agg:
                return y
            else:
                return y.unsqueeze(0), torch.tensor(1., device=y.device)