"""
This module provides the FlowNode,
an implementation of a DCU using Normalizing Flows.
"""

import torch
from torch import nn

from .node import CausalNode
from .latents import LatentNormal

from flow import Sequential, inv_flow
from flow.conditioner import AutoregressiveNaive, MADE
from flow.transformer import DSF, Spline
from flow.modules import BatchNorm, Shuffle, Affine, Sigmoid, Softplus, Scaler, Exponential
from flow.prior import Normal


# # Default flow for a FlowNode. n Spline Conditional Flows.
# # We'll only use 1 to avoid instability during training
# def flow(n_flows=1, dim=1, cond_dim=0, trnf=DSF, reversed=False):
#     """Return the Flow to use in a FlowNode.

#     Defaults to:
#     ```python
#     Sequential(
#         BatchNorm(dim=dim, affine=False),
#         Shuffle(dim=dim)
#         Conditioner(trnf(dim=dim), cond_dim=cond_dim),
#     ) * n_flows
#     ```

#     where Conditioner is AutoregressiveNaive for dim=1 and MADE for dim > 1.
#     """
    
#     trnf = inv_flow(trnf) if reversed else trnf
#     bn = inv_flow(BatchNorm) if reversed else BatchNorm
#     shuffle = inv_flow(Shuffle) if reversed else Shuffle
    

#     flow = lambda: (
#         AutoregressiveNaive(trnf(dim=dim), cond_dim=cond_dim) if dim == 1 
#         else MADE(trnf(dim=dim), cond_dim=cond_dim)
#     )

#     block = lambda: Sequential(
#         bn(dim=dim, affine=False),
#         shuffle(dim=dim), # if dim == 1 it is the identity
#         flow()
#     )

#     return Sequential(*(
#         block()
#         for n_layer in range(n_flows)
#     ))


def flow(dim=1, cond_dim=0, activation=None, head_slices=[]):
    from functools import partial
    trnf = partial(Spline, K=5)
    
    assert not (head_slices and dim > 1), 'Not implemented yet'

    flow = lambda: (
        AutoregressiveNaive(trnf(dim=dim), cond_dim=cond_dim, head_slices=head_slices) if dim == 1 
        else MADE(trnf(dim=dim), cond_dim=cond_dim)
    )

    from flow.prior import Uniform, Normal

    S = partial(Sigmoid, dim=dim)
    IS = partial(inv_flow(Sigmoid), dim=dim)

    block = lambda: (
        IS(),
        flow(),
        S(),
        BatchNorm(dim=dim, affine=False)
    )

    return Sequential(
        Affine(dim=dim),
        *block(),
        *block(),
        *block(),
        *([activation(dim=dim)] if activation is not None else []),
        prior=Normal(dim)
    )

    
class NCF(CausalNode):
    """Normalizing Causal Flow.

    https://arxiv.org/abs/2006.08380

    Uses Normalizing Flows as the Causal Mechanism for a SCM.
    """
    
    latent = False
    discrete = False

    @property
    def undiscretize(self):
        return self._undiscretize.item()
    
    def __init__(
        self, 
        name, *parents, dim=1,
        flow=flow, positive=False,
        undiscretize=False, undiscretize_sigma=.5 / 1.96,
        head_parents=[],
        **kwargs
    ):
        """
        Args:
            name (str): name of the node.
            *parents (CausalNode): nodes that act as parents for this node.
            dim (int): dimensionality of the r.v. described by this node.
            flow (function): function(dim=1, cond_dim=0) that returns 
                a conditional Flow with these dimensions.
                Defaults to `flow`.
            undiscretize (bool): whether to undiscretize discrete signals
                (by adding Normal noise) so as to learn ordinal variables
                as continuous variables.
            undiscretize_sigma (float): scale of the Normal noise
                added when undiscretizing.

        Remember that any `flow` used as a CausalNode 
        should have BatchNorm as the initial step
        so as to normalize the node's distribution.
        Also, this flow should be conditional
        so as to take into account the node's parent values.
        """
        
        super().__init__(name, *parents, dim=dim)

        self.cond_dim = sum(p.dim for p in self.parents)
        
        if positive:
            activation = lambda dim: Sequential(
                inv_flow(Softplus)(dim=dim), 
                inv_flow(Scaler)(dim=dim)
            )
        else:
            activation = None
            
        # If there are head_parents, determine their slices
        head_slices = []
        for pname in head_parents:
            start = 0
            for parent in parents:
                end = start + parent.dim
                if parent.name == pname:
                    head_slices.append(slice(start, end))
                    break
                start = end

        self.flow = flow(self.dim, self.cond_dim, activation, head_slices=head_slices)

        self.register_buffer('_undiscretize', torch.tensor(undiscretize))
        self.register_buffer(
            'undiscretize_sigma', 
            torch.tensor(undiscretize_sigma)
        )


    # Overrides for CausalNode:
    def _ex_nodes(self):
        return LatentNormal(self.name + '.ex', dim=self.dim)
    
    def _ex_invertible(self):
        return True

    def _process_parents(self, n, *parents):
        # Override _process_parents to split parents and ex 
        # and stack each group in single tensors.
        parents = super()._process_parents(n, *parents)
        parents, ex = \
            parents[:-len(self.ex_noise)], parents[-len(self.ex_noise):]

        parents = torch.cat(parents, 1) if parents else None
        ex = torch.cat(ex, 1) if ex else None

        return parents, ex
    
    def sample(self, n, *parents, **kwargs):
        # kwargs are passed to flow.invert
        parents, ex = self._process_parents(n, *parents)
        
        sample = self.flow(ex, invert=True, cond=parents, **kwargs)

        return sample

    def nll(self, y, *parents, ex_n=100):
        n = y.size(0)
        parents, _ = self._process_parents(n, *parents)

        if self.training and self.undiscretize:
            y = y + torch.randn_like(y) * self.undiscretize_sigma
        
        nll = self.flow.nll(y, cond=parents)

        return nll
    
    def abduct(self, y, *parents):
        n = y.size(0)
        parents, _ = self._process_parents(n, *parents)

        ex_y = self.flow(y, cond=parents)

        return (ex_y,)
        
    # Need to override `to` method so flow has updated device
    def _update_device(self, device):
        super()._update_device(device)
        self.flow._update_device(device)
        
        return self