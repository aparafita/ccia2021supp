"""
Provides an abstract class for Distributional Causal Nodes (DCN).
"""

import torch
from torch import nn

from ..node import CausalNode
from ..latents import LatentNode, LatentNormal
from ..utils import log_mean_exp_trick
from .parameters import ParameterNet, Parameter

from flow.utils import MultiHeadNet
from functools import partial


class DCN(CausalNode):
    """Abstract class for any Distributional Causal Node (DCN).

    Any class that inherits from this one must override the following methods:
    ```python
        def _params(self): 
            # Returns the tuple of parameters 
            # that define this node's r.v. distribution.
            ...

        def _ex_nodes(self):
            # Create and return exogenous noise nodes
            ...

        def _ex_invertible(self):
            # Return whether this node can invert ex_noise exactly
            ...

        def _sample(self, n, *params, *ex): 
            # Sample from the distribution, given the parameters.
            ...

        def _nll(self, y, *params):
            # Compute the nll of y given the parameters.
            ...

        def _abduct(self, y, *params):
            # Inverts (or samples from the distribution of) ex_noise
            # given y and params.
            ...
    ```

    Also, override the following parameters:
    
    * discrete (bool): whether the corresponding r.v. is discrete.
    """

    @property
    def normalize(self):
        return self._normalize_bool.item()

    latent = False # DCNs are learnable, so always non-latent

    def __init__(
        self, node, *parents, parameters_net=None,
        normalize=True, normalize_eps=1e-6, 
        head_parents=[], **kwargs
    ):
        """
        Args:
            name (str): name of the node.
            *parents (CausalNode): nodes that act as parents for this node.
            parameters_net (function): 
                function(input_dim, output_dim) that returns 
                a network used for parameter estimation, given parents values.
            normalize (bool): whether to normalize the values of this node
                while executing sample and nll for better numerical stability.
            normalize_eps (float): minimum value for scale during normalization.
        """

        super().__init__(node, *parents, **kwargs)

        # Note that we exclude ex_noise from input_dim, 
        # since they don't enter the net
        self.input_dim = sum(p.dim for p in self.parents)

        params = self._params()
        if not any(isinstance(params, t) for t in [list, tuple, set]):
            params = (params,)
        self.params = tuple(params)
        
        # If there are head_parents, determine their slices
        head_slices = []
        for pname in head_parents:
            start = 0
            for parent in parents:
                end = start + parent.dim
                if parent.name == pname:
                    head_slices.append(slice(start, end))
                    break
                start = end
            
        if head_slices:
            assert parameters_net is None
            parameters_net = partial(MultiHeadNet, use_dropout=True, use_bn=False, head_slices=head_slices)

        self.params_net = ParameterNet(
            self.input_dim, *self.params, net_f=parameters_net
        )

        self.register_buffer('_normalize_bool', torch.tensor(normalize))
        self.register_buffer('_normalize_eps', torch.tensor(normalize_eps))

        if self.normalize:
            self.register_buffer('_normalize_bias', torch.randn(self.dim))
            self.register_buffer('_normalize_log_weight', torch.randn(self.dim))


    # Normalize functions
    def warm_start(self, y):
        if self.normalize:
            self._normalize_bias.data = y.mean(dim=0)
            self._normalize_log_weight.data = torch.log(
                y.std(dim=0) + self._normalize_eps
            )

        return self

    def _normalize(self, y):
        """Normalize y with BatchNorm.

        Returns (y, log|det T(y)|) where T(y) is BatchNorm(y).
        """

        loc, log_scale = self._normalize_bias, self._normalize_log_weight
        scale = torch.exp(log_scale)

        y = (y - loc) / scale
        log_det = -log_scale.unsqueeze(0).sum(dim=1)

        return y, log_det

    def _denormalize(self, y):
        """Denormalize a normalized y from the parameters in BatchNorm.

        Returns y denormalized.
        """

        loc, log_scale = self._normalize_bias, self._normalize_log_weight
        scale = torch.exp(log_scale)

        y = y * scale + loc

        return y


    # Overrides for CausalNode:
    def _process_parents(self, n, *parents):
        # Override _process_parents to split parents and ex 
        # and stack each group in single tensors.
        parents = super()._process_parents(n, *parents)
        parents, ex = \
            parents[:-len(self.ex_noise)], parents[-len(self.ex_noise):]

        return parents, ex

    def sample(self, n, *parents):
        parents, ex = self._process_parents(n, *parents)

        params = self.params_net(n, *parents)
        sample = self._sample(n, *params, *ex)
        
        assert sample.shape == (n, self.dim), (sample.shape, (n, self.dim))
        assert sample.device.type == self.device.type, \
            (sample.device, self.device)

        if self.normalize:
            sample = self._denormalize(sample)

        return sample

    def nll(self, y, *parents):
        n = y.size(0)
        parents, _ = self._process_parents(n, *parents)

        params = self.params_net(n, *parents)

        if self.normalize:
            y, log_det = self._normalize(y)

        nll = self._nll(y, *params)
        assert nll.shape == (n,), (self, nll.shape, n)

        if self.normalize:
            nll = nll - log_det

        return nll

    def abduct(self, y, *parents):
        n = y.size(0)
        parents, _ = self._process_parents(n, *parents)

        params = self.params_net(n, *parents)

        if self.normalize:
            y, _ = self._normalize(y)

        ex = self._abduct(y, *params)
        
        if not any(isinstance(ex, t) for t in (list, tuple, set)):
            ex = (ex,)

        assert (e.shape == (n, ex.dim) for e, ex in zip(ex, self.ex_noise))

        return tuple(ex)


    # To override:
    def _params(self):
        """Create Parameter instances."""
        raise NotImplementedError()

    def _sample(self, n, *args): # *params, *ex_noise
        """Return a sample given the r.v. params and an ex_noise sample.
    
        Args:
            n (int): number of samples to sample.
            *args (torch.Tensor): contains both *params and *ex_noise.
        """
        raise NotImplementedError()

    def _nll(self, y, *params):
        """Return the nll of y given the distribution's parameters.

        Args:
            y (torch.Tensor): values to compute the nll of.
            *params (torch.Tensor): tensors with the values 
                for each parameter in self.params.
        """
        raise NotImplementedError()

    def _abduct(self, y, *params):
        """Return ex_noise values such that the node with this params creates y.

        Args:
            y (torch.Tensor): values to recreate from ex_noise.
            *params (torch.Tensor): tensors with the values
                for each parameter in self.params.
        """
        raise NotImplementedError()