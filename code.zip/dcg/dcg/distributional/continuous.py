"""Includes implementations for DCNs with continuous random variables."""

from functools import partial

import numpy as np

import torch
from torch import nn
import torch.nn.functional as F

from .distributional import DCN
from .parameters import * # parameters_net, Parameter, ParameterLoc, etc.

from ..latents import LatentUniform, LatentNormal


class ContinuousDCN(DCN):
    """Abstract class for Continuous DCNs.

    Only ensures that all nodes are marked as non-discrete.
    """

    discrete = False

    def __init__(self, *args, **kwargs):
        """"""
        super().__init__(*args, **kwargs)

        assert not self.discrete, self


class Normal(ContinuousDCN):
    """Normal distribution."""

    # Overrides:
    def _params(self):
        return ParameterLoc(dim=self.dim), ParameterScale(dim=self.dim)

    def _ex_nodes(self):
        return LatentNormal(self.name + '.ex', dim=self.dim)

    def _ex_invertible(self):
        return True

    def _sample(self, n, loc, scale, ex):
        return ex * scale + loc

    def _nll(self, y, loc, scale):
        return .5 * (
            self.dim * np.log(2 * np.pi) + 2 * torch.log(scale).sum(dim=1) + 
            (((y - loc) / scale) ** 2).sum(dim=1)
        )

    def _abduct(self, y, loc, scale):
        return (y - loc) / scale


class ALD(ContinuousDCN):
    """Asymmetric Laplace Distribution."""

    def __init__(self, *args, uniform_eps=1e-3, **kwargs):
        if kwargs.get('dim', 1) > 1:
            raise NotImplementedError()

        object.__setattr__(self, 'uniform_eps', uniform_eps)

        super().__init__(*args, **kwargs)


    # Overrides:
    def _params(self):
        return ParameterLoc(), ParameterScale(), ParameterShape()

    def _ex_nodes(self):
        return LatentUniform(
            self.name + '.ex', dim=self.dim, 
            eps=self.uniform_eps
        )

    def _ex_invertible(self):
        return True

    def _sample(self, n, loc, scale, shape, ex):
        ex = ex * (1 / shape + shape) - shape # U(-shape, 1 / shape)

        sign = torch.sign(ex)
        sign[sign == 0] = 1.

        return loc - 1 / (scale * sign * (shape ** sign)) * torch.log(
            1 - ex * sign * (shape ** sign)
        )

    def _nll(self, y, loc, scale, shape):
        sign = torch.sign(y - loc)
        sign[sign == 0] = 1.

        return -(
            torch.log(scale) - torch.log(shape + 1 / shape) - 
            (y - loc) * scale * sign * (shape ** sign)
        ).squeeze(1)

    def _abduct(self, y, loc, scale, shape):
        sign = torch.sign(y - loc)
        sign[sign == 0] = -1.

        noise = (
            1 - torch.exp((loc - y) * scale * sign * shape ** sign)
        ) * sign * shape ** -sign
        
        return (noise + shape) / (1 / shape + shape)