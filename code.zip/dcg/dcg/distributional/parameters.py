"""Includes an abstract class for a DCN Parameter, 
and several implementations for each type of Parameter.
"""

import numpy as np

import torch
from torch import nn

import torch.nn.functional as F


def parameters_net(
    input_dim, output_dim, n_layers=3, hidden_dim=100, use_dropout=True
):
    """Create a network for computation of parameters.

    Args:
        input_dim (int): input dimension for network.
        output_dim (int): output dimension for network. 
            Basically, concatenation of parameter dimensions.
        n_layers (int): number of layers in network.
        hidden_dim (int): dimension of hidden layers.
    """
    assert input_dim > 0, 'Net with no inputs'
    assert n_layers >= 1, 'Net with no layers'

    def step(n, k):
        if k == 0:
            return nn.Linear(
                input_dim if n == 0 else hidden_dim, 
                hidden_dim
            )
        elif k == 1:
            if use_dropout:
                return nn.Dropout()
            else:
                return None
        else:
            return nn.ReLU()

    return nn.Sequential(
        nn.BatchNorm1d(input_dim, affine=False),
        *(
            layer
            for layer in (
                step(n_layer, n_step)

                for n_layer in range(n_layers - 1)
                for n_step in range(3)
            )
            if layer is not None
        ),
        nn.Linear(input_dim if n_layers == 1 else hidden_dim, output_dim)
    )


class ParameterNet(nn.Module):
    """Network that computes the value of a node's distribution parameters.

    Given the conditioning parent's values of a node, 
    outputs the resulting parameters for the node's assumed distribution.
    """

    def __init__(self, input_dim, *params, net_f=None):
        """
        Args:
            input_dim (int): input dimension.
            *params (Parameter): required parameters.
            net_f (function): 
                function(input_dim, output_dim) that returns 
                a network that computes parameters values.
                If None, defaults to `parameters_net`.
        """

        super().__init__()

        assert params
        self.params = params

        assert input_dim >= 0
        self.input_dim = input_dim
        self.output_dim = sum(p.dim for p in params)

        if self.input_dim:
            if net_f is None:
                net_f = parameters_net

            self.net = net_f(self.input_dim, self.output_dim)
        else:
            self._params = nn.Parameter(
                torch.cat([ p.init(1, p.dim) for p in params ], dim=1)
            )

    def forward(self, n, *parents):
        assert all(p.size(0) == n for p in parents)
        assert sum(p.size(1) for p in parents) == self.input_dim

        # Prepare input tensor
        if parents:
            params = self.net(torch.cat(parents, dim=1))
        else:
            params = self._params.repeat(n, 1)

        assert params.shape == (n, self.output_dim), \
            f"Parameter shape {params.shape} doesn't match "\
            f"expected shape: (n, {self.output_dim})"

        # Now, split params as specified by each parameter.dim 
        # and use their corresponding forward method.
        params_t = tuple()
        i = 0
        for p in self.params:
            j = i + p.dim
            p = p(params[:, i:j]) # pass activation function
            params_t += (p,)
            i = j

        return params_t


class Parameter(nn.Module):
    """Class used to represent a DCN distribution's Parameter.

    Defines the name of the parameter, its dimensionality,
    an optional activation function to condition its domain
    (i.e., strictly positive parameters with a softplus + eps activation)
    and an optional initialization function for a learnable tensor.

    The activation function is defined in the forward method.
    """

    def __init__(self, name, dim=1, init=None):
        """
        Args:
            name (str): name of the parameter.
            dim (int): dimension of the parameter.
            init (function): initialization function(*shape) for the parameter.
                This is only used if Parameter is computed
                with a learnable, constant tensor (not conditioned by an input).
                If None, defaults to torch.randn.
        """

        super().__init__()

        self.name = name
        self.dim = dim

        if init is None:
            init = torch.randn

        self.init = init

    def forward(self, x):
        return x # default


# Parameter implementations:

class ParameterLoc(Parameter):
    r"""Location parameter in domain (a, b) (including infinity).

    Note that in all cases the interval is open, due to the effect
    of a small constant eps specified in the constructor.

    Every domain specifies a different activation function.
    """

    def __init__(self, name='loc', a=-np.inf, b=np.inf, eps=1e-6, **kwargs):
        super().__init__(name, **kwargs)

        self.a = a
        self.b = b
        assert 0 < eps and eps < .5
        self.eps = eps

        self.inf_a = np.isinf(a)
        self.inf_b = np.isinf(b)

        self.truncated = not (self.inf_a and self.inf_b)

    def forward(self, x):
        a, b = self.a, self.b
        inf_a, inf_b = self.inf_a, self.inf_b

        if self.truncated:
            if not inf_a and not inf_b:
                s = torch.sigmoid(x) * (1 - self.eps) + self.eps / 2.
                return s * (b - a) + a
            else:
                x = F.softplus(x) + self.eps

                if inf_a:
                    return b - x
                else: # inf_b
                    return a + x
        else:
            return x


class ParameterScale(ParameterLoc):

    def __init__(self, name='scale', eps=1e-6, **kwargs):
        super().__init__(name, a=0., eps=eps, **kwargs)


class ParameterLogScale(Parameter):
    r"""Log-scale parameter, with all reals as domain."""

    def __init__(self, name='logscale', **kwargs):
        super().__init__(name, **kwargs)

    def forward(self, x):
        return x


class ParameterShape(ParameterScale):

    def __init__(self, name='shape', eps=1e-6, **kwargs):
        super().__init__(name, eps=eps, **kwargs)


class Parameter01(ParameterLoc):

    def __init__(self, name, eps=1e-6, **kwargs):
        super().__init__(name, a=0., b=1., eps=eps, **kwargs)


class ParameterCategorical(Parameter):
    """Parameter for a Categorical distribution, log p."""

    def __init__(self, name='log_p', dim=2, **kwargs):
        assert dim >= 2

        super().__init__(name, dim=dim, **kwargs)

    def forward(self, x):
        return torch.log_softmax(x, dim=1)


class ParameterBernoulli(Parameter):
    """Parameter for a Bernoulli distribution, log p pre-activation.

    Returns the parameter tensor pre-activation. This is needed,
    since the input dimension will be 1 but the output will be 2.

    When using this parameter, call parameter.activation(x).
    This returns a 2-dim tensor, containing log((1 - p, p)).
    By returning two dimensions, we can use the Categorical functions. 
    """

    def __init__(self, name='_log_p', **kwargs):
        assert kwargs.get('dim', 1) == 1
        super().__init__(name, **kwargs)

    # Note that forward won't do anything

    def activation(self, x):
        assert x.size(1) == 1 # we'll transform it to 2
        
        return torch.cat([
            F.logsigmoid(-x), # log(1 - sigmoid(x)) = log sigmoid(-x)
            F.logsigmoid(x)
        ], 1)