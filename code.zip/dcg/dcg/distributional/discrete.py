"""Includes implementations for DCNs with discrete random variables."""

from functools import partial

import numpy as np

import torch
from torch import nn
import torch.nn.functional as F

from .distributional import DCN
from .parameters import ParameterBernoulli, ParameterCategorical, \
    ParameterLogScale
from ..latents import LatentGumbel, LatentUniform
from ..sampling import gumbel, categorical, uniform
from ..utils import log_sum_exp_trick


class DiscreteDCN(DCN):
    """Abstract class for Discrete DCNs.

    Only ensures that all nodes are marked as discrete.
    Also that these nodes are not normalized.
    """

    discrete = True

    def __init__(self, *args, **kwargs):
        """"""
        kwargs.pop('normalize', False) # we shouldn't normalize in discrete r.v.

        super().__init__(*args, normalize=False, **kwargs)

        assert self.discrete, self


def _abduct_gumbel(y, log_p):
    """Given a one-hot y and the corresponding log_p parameters,
    samples from the abducted Gumbel distribution that produced this sample.
    """
    n = y.size(0)
    device = y.device
    
    log_p_k = (log_p * y).sum(1)
    g_k = gumbel(n, device=device) - log_p_k
    g = -torch.log(
        torch.exp(-gumbel(n, y.size(1), device=device) - log_p) + 
        torch.exp(-g_k - log_p_k).unsqueeze(1)
    ) - log_p
    
    g = (y > .5) * g_k.unsqueeze(1) + (y < .5) * g
    
    return g


class Categorical(DiscreteDCN):
    """Categorical distribution. 

    Use this class (preferably) when #categories > 2.
    Otherwise, use Bernoulli."""

    def __init__(self, name, *parents, temperature=1e-2, **kwargs):
        assert kwargs.get('dim', 1) > 1, \
            f'Categorical defined by dim > 1: {self}'

        super().__init__(name, *parents, **kwargs)

        self.register_buffer('temperature', torch.tensor(temperature))


    # Overrides:
    def _params(self):
        return ParameterCategorical(dim=self.dim)

    def _ex_nodes(self):
        return LatentGumbel(self.name + '.ex', dim=self.dim)

    def _ex_invertible(self):
        return False

    def _sample(self, n, log_p, ex):
        return categorical(
            n, log_p, ex, 
            soft=False, temperature=self.temperature
        )

    def _nll(self, y, log_p):
        return -(y * log_p).sum(dim=1)

    def _abduct(self, y, log_p):
        return _abduct_gumbel(y, log_p)


class Bernoulli(DiscreteDCN):
    """Bernoulli distribution.

    Even though it could be modelled as a Categorical(dim=2), 
    Bernoullis have 1 dimension. That way, we only learn 1 parameter.
    """

    def __init__(self, name, *parents, temperature=1e-2, **kwargs):
        assert kwargs.get('dim', 1) == 1, \
            f'Bernoulli defined by dim == 1: {self}'

        super().__init__(name, *parents, **kwargs)

        self.register_buffer('temperature', torch.tensor(temperature))

    # Overrides:
    def _params(self):
        return ParameterBernoulli()

    def _ex_nodes(self):
        return LatentGumbel(self.name + '.ex', dim=2)

    def _ex_invertible(self):
        return False

    def _activation(self, log_p):
        # Need to transform our 1-dimensional log_p pre-activation tensor
        # into a 2-dimensional post-activation log_p tensor.
        return self.params[0].activation(log_p)

    def _sample(self, n, log_p, ex):
        log_p = self._activation(log_p)

        return categorical(
            n, log_p, ex, 
            soft=False, temperature=self.temperature
        )[:, [1]]

    def _nll(self, y, log_p):
        y = torch.cat([1 - y, y], 1)
        log_p = self._activation(log_p)

        return -(y * log_p).sum(dim=1)

    def _abduct(self, y, log_p):
        y = torch.cat([1 - y, y], 1)
        log_p = self._activation(log_p)

        return _abduct_gumbel(y, log_p)


class Poisson(DiscreteDCN):
    """Poisson distribution.
    
    Note that if dim > 1, 
    they will be mutually independent Poissons given their parents.
    """

    def __init__(self, name, *parents, eps=1e-3, **kwargs):
        super().__init__(name, *parents, **kwargs)

        self.register_buffer('eps', torch.tensor(eps))

    # Overrides:
    def _params(self):
        return ParameterLogScale(dim=self.dim)

    def _ex_nodes(self):
        return LatentUniform(self.name + '.ex', dim=self.dim)

    def _ex_invertible(self):
        return False

    def _sample(self, n, log_l, ex):
        # Using inverse transform sampling
        y = torch.zeros_like(log_l)
    
        if ex is None:
            ex = uniform(*log_l.shape, device=log_l.device, eps=self.eps)

        log_ex = torch.log(ex)

        log_p = -torch.exp(log_l)
        log_s = log_p.clone()

        idx = log_ex > log_s
        current_y = 0
        while idx.any().item():
            current_y += 1
            y[idx] += 1

            log_p[idx] += log_l[idx] - np.log(current_y)
            log_s[idx] = log_sum_exp_trick(
                torch.stack([log_s[idx], log_p[idx]], -1)
            )

            idx = log_ex > log_s

        return y

    def _nll(self, y, log_l):
        y = y.float().round().long()
        
        i = torch.arange(y.max().item() + 1, device=y.device).float()
        
        i[0] = 1
        log_fact = torch.cumsum(torch.log(i), 0)
        
        return -(y * log_l - torch.exp(log_l) - log_fact[y]).sum(dim=1)

    def _abduct(self, y, log_l):
        y = y.float().round().int().clone()
        ex = uniform(*log_l.shape, device=y.device)

        log_p = -torch.exp(log_l)
        log_s = log_p.clone()

        # Update u for those y == 0
        idx = y == 0
        ex[idx] *= torch.exp(log_s[idx])

        current_y = 0
        while (y > 0).any().item():
            current_y += 1
            y -= 1
            idx = y >= 0
            idx2 = y == 0

            log_p[idx] += log_l[idx] - np.log(current_y)

            prev_s = torch.exp(log_s[idx2])
            log_s[idx] = log_sum_exp_trick(
                torch.stack([log_s[idx], log_p[idx]], -1)
            )

            # Update u for those y == 0
            ex[idx2] = ex[idx2] * (torch.exp(log_s[idx2]) - prev_s) + prev_s

        ex = ex.clamp(self.eps / 2, 1 - self.eps / 2)

        return ex