"""
This module provides miscellaneous nn.Modules and CausalNodes.

* `InputNode`
"""

import numpy as np
import torch
from torch import nn

from .node import CausalNode
from .latents import LatentGumbel
from .sampling import categorical
from .utils import log_sum_exp_trick


class InputNode(CausalNode):
    """Direct input Causal Node.

    Useful to include input tensors 
    directly to the causal graph as interventions.

    Its nll will always be 0 to ignore its effects (just like interventions),
    and doesn't have implementations for sample and abduct. 
    """

    latent = False
    # discrete is defined as a constructor parameter

    def __init__(self, name, *parents, discrete=False, **kwargs):
        """
        Args:
            name (str): name of the node.
            *parents (CausalNode): parents of the node.
            discrete (bool): whether the node is discrete or continuous.

        Note that even if this node may have parents, 
        it should always come as an intervention to the graph.
        """

        object.__setattr__(self, 'discrete', discrete) # set before init
        object.__setattr__(self, '_trainable', False)

        super().__init__(name, *parents, **kwargs)

    # Overrides
    def _ex_nodes(self):
        return # none

    def sample(self, n, *parents):
        # Should not be called, since its values always come from intervention.
        raise NotImplementedError()

    def nll(self, y, *parents, ex_n=100):
        return torch.zeros_like(y[:, 0])

    def _ex_invertible(self):
        # Has no ex_noise, so True
        return True

    def abduct(self, y, *parents):
        # Should not be called, since its values always come from intervention.
        raise NotImplementedError()


class MixtureNode(CausalNode):
    
    latent = False

    @staticmethod
    def _check_mixture_nodes(mixture_nodes, parents=None):
        assert len(mixture_nodes)
        unique = lambda f, it: len(set(f(x) for x in it)) == 1

        if parents is None:
            parents = mixture_nodes[0].parents
        
        assert (
            isinstance(mixture_nodes, (tuple, list, set)) and
            mixture_nodes and
            unique(lambda x: x.name, mixture_nodes) and
            all(
                len(parents) == len(node.parents) and all(
                    p1.name == p2.name
                    for p1, p2 in zip(parents, node.parents)
                )
                for node in mixture_nodes
            ) and 
            unique(lambda x: x.discrete, mixture_nodes) and
            unique(lambda x: len(x.ex_noise), mixture_nodes) and
            all(
                unique(lambda x: (x.name, x.dim, x.discrete), ex)
                for nodes in zip(*mixture_nodes)
                for ex in zip(*map(lambda node: node.ex_noise, nodes))
            )
        )

    @classmethod
    def from_nodes(cls, mixture_nodes, parents, w=None, **kwargs):
        cls._check_mixture_nodes(mixture_nodes, parents)

        n = mixture_nodes[0]
        return cls(
            n.name, *parents, 
            dim=n.dim, mixture_nodes=mixture_nodes, w=w, **kwargs
        )
    
    def __init__(self, name, *parents, dim=1, mixture_nodes=[], w=None, **kwargs):
        self._check_mixture_nodes(mixture_nodes, parents)
        
        object.__setattr__(self, 'discrete', mixture_nodes[0].discrete)
        object.__setattr__(self, 'mixture_nodes', mixture_nodes)
        
        K = len(mixture_nodes)
        object.__setattr__(self, 'K', K)
        
        super().__init__(name, *parents, dim=dim, **kwargs)
        
        object.__delattr__(self, 'mixture_nodes')
        self.mixture_nodes = nn.ModuleList(mixture_nodes)
        
        # Replace mixture_nodes elements
        for node in mixture_nodes:
            node.ex_noise = self.ex_noise[1:]
            node.parents = parents
            node._parents = parents + tuple(self.ex_noise[1:])
        
        if w is None:
            w = torch.full((K,), 1 / K)
        else:
            assert (
                isinstance(w, torch.Tensor) and 
                w.flatten().shape == (K,) and
                ((w > 0) & (w < 1)).all().item()
            )
            
        w = w.view(1, K)
        self.log_w = nn.Parameter(torch.log(w))
        
        
    # To override:
    def to(self, device):
        # only update device since the call 
        # super().to(device) will move them to device
        for node in self.mixture_nodes:
            node._update_device(device) 
            
        return super().to(device)
    
    def _ex_nodes(self):
        """Create exogenous noise nodes."""
        return (LatentGumbel(self.name + '.gumbel', dim=self.K),) + \
            tuple(self.mixture_nodes[0].ex_noise)

    def _ex_invertible(self):
        """Whether ex_noise can be inverted from y and parents.

        This is required for counterfactual estimation.
        """
        return False

    def warm_start(self, x):
        """Warm start the node with some values x."""
        for node in self.mixture_nodes:
            node.warm_start(x)
            
        return self # default behaviour
    
    def _process_parents(self, n, *parents):
        parents = super()._process_parents(n, *parents)
        
        parents, ex = parents[:len(self.parents)], parents[len(self.parents):]
        gumbel, ex = ex[0], ex[1:]
        
        return parents, gumbel, ex

    def sample(self, n, *parents):
        """Sample from this node's r.v., conditioned on its parents.

        Args:
            n (int): number of instances to sample.
            *parents (torch.Tensor): parents values.
        """
        parents, gumbel, ex = self._process_parents(n, *parents)
        
        components = categorical(n, self.log_w, gumbel)
        
        return (
            components.unsqueeze(2) * 
            torch.stack([
                node.sample(n, *parents, *ex)
                for node in self.mixture_nodes
            ], 1)
        ).sum(1)

    def nll(self, y, *parents):
        """Negative Log-Likelihood of tensor y conditioned on its parents.

        Args:
            y (torch.Tensor): observable values for the node.
            *parents (torch.Tensor): parent values.
        """
        n = y.size(0)
        parents, _, _ = self._process_parents(n, *parents)
        
        return -log_sum_exp_trick(
            -torch.stack([
                node.nll(y, *parents)
                for node in self.mixture_nodes
            ], 1),
            log_w=self.log_w
        )

    def abduct(self, y, *parents):
        """Sample ex_noise conditioned on y and its parents.

        Args:
            y (torch.Tensor): observable values for the node.
            *parents (torch.Tensor): parent values.
        """
        n = y.size(0)
        parents, gumbel, ex = self._process_parents(n, *parents)
        
        components = categorical(n, self.log_w, gumbel)
        
        return (gumbel,) + tuple(
            (
                components.unsqueeze(2) * 
                torch.stack([ ex for ex in ex_t ], 1)
            ).sum(1)
            for ex_t in zip(*(
                node.abduct(y, *parents, *ex)
                for node in self.mixture_nodes
            ))
        )


class MultiheadedNode(CausalNode):
    
    latent = False
    
    def __init__(self, name, *parents, dim=1, subnode_cls=None, head_parents=[], **kwargs):        
        assert (
            isinstance(head_parents, (list, tuple, set)) and 
            all(isinstance(p, str) for p in head_parents) and
            set(head_parents) <= set(p.name for p in parents) and
            all(p.discrete for p in parents if p.name in head_parents)
        )
        
        if not head_parents:
            head_parents = [ p.name for p in parents if p.discrete ]
        
        parents_dict = { p.name: p for p in parents }
        
        combinations = [
            max(p.dim, 2)
            for p in (parents_dict[p] for p in head_parents)
        ]
        
        def combs(lens):
            if not lens:
                yield []
            else:
                for i in range(lens[0]):
                    for rest in combs(lens[1:]):
                        yield [i] + rest
                        
        def onehot(comb, lens):
            res = []
            
            for c, l in zip(comb, lens):
                res += [ c == i for i in range(l) ]
                
            return res
        
        combinations = torch.Tensor([
            onehot(comb, combinations)
            for comb in combs(combinations)
        ]).int()
        
        heads = [
            subnode_cls(
                name + '.%d' % i, 
                *(p for p in parents if p.name not in head_parents), 
                dim=dim, 
                **kwargs
            )
            for i in range(len(combinations))
        ]
        
        # For ex_noise to use when calling __init__
        object.__setattr__(self, 'combinations', combinations)
        object.__setattr__(self, 'heads', heads)
        
        object.__setattr__(self, 'discrete', all(h.discrete for h in heads))
        
        super().__init__(name, *parents, dim=dim)
        
        object.__delattr__(self, 'combinations')
        object.__delattr__(self, 'heads')
        
        self.heads = nn.ModuleList(heads)
        self.register_buffer('combinations', combinations)
        self.head_parents = head_parents
        
        
    # To override:
    def _ex_nodes(self):
        """Create exogenous noise nodes."""
        return tuple(self.heads[0].ex_noise)

    def _ex_invertible(self):
        """Whether ex_noise can be inverted from y and parents.

        This is required for counterfactual estimation.
        """
        return all(h._ex_invertible() for h in self.heads)

    # Can't warm_start without the value for its parents, so no warm_start
    # TODO: Enable passing of parents to warm_start so we can complete this function
    
    def _apply_multihead(self, *parents, n=None, y=None, op=None):
        if n is None:
            assert y is not None
            n = y.size(0)
            
        parents = super()._process_parents(n, *parents)
        subparents = [t for p, t in zip(self._parents, parents) if p.name not in self.head_parents]
        
        parents_dict = { p.name: t for p, t in zip(self._parents, parents) }
        
        comb = (torch.cat([
            t if t.size(1) > 1 else torch.cat([1 - t, t], 1)
            for t in (parents_dict[k] for k in self.head_parents)
        ], 1) > .5).int()
        
        comb_idx = torch.arange(len(self.combinations)).view(1, -1).repeat(n, 1)[
            (comb.unsqueeze(1) == self.combinations.unsqueeze(0)).all(2)
        ]
        
        assert len(comb_idx.shape) == 1
        
        if op == 'sample':
            result = torch.zeros(n, self.dim, device=self.device)
        elif op == 'nll':
            result = torch.zeros(n, device=self.device)
        elif op == 'abduct':
            result = [
                torch.zeros(n, ex.dim, device=self.device)
                for ex in self.ex_noise
            ]
        
        for i in torch.unique(comb_idx):
            idx = comb_idx == i
            head = self.heads[i]
            
            if op == 'sample':
                result[idx] = head.sample(idx.sum().item(), *(p[idx] for p in subparents))
            elif op == 'nll':
                result[idx] = head.nll(y[idx], *(p[idx] for p in subparents))
            elif op == 'abduct':
                for r, ex in zip(result, head.abduct(y[idx], *(p[idx] for p in subparents))):
                    r[idx] = ex
                    
        return result
        

    def sample(self, n, *parents):
        """Sample from this node's r.v., conditioned on its parents.

        Args:
            n (int): number of instances to sample.
            *parents (torch.Tensor): parents values.
        """
        return self._apply_multihead(*parents, n=n, op='sample')

    def nll(self, y, *parents):
        """Negative Log-Likelihood of tensor y conditioned on its parents.

        Args:
            y (torch.Tensor): observable values for the node.
            *parents (torch.Tensor): parent values.
        """
        return self._apply_multihead(*parents, y=y, op='nll')

    def abduct(self, y, *parents):
        """Sample ex_noise conditioned on y and its parents.

        Args:
            y (torch.Tensor): observable values for the node.
            *parents (torch.Tensor): parent values.
        """
        return self._apply_multihead(*parents, y=y, op='abduct')