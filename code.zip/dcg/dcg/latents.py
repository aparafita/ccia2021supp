"""
Provides latent CausalNodes to use them as exogenous noise signals.

* `LatentNode`: abstract class for any latent nodes.
* `LatentUniform`: Uniform distribution latent node.
* `LatentNormal`: Normal distribution latent node.
* `LatentGumbel`: Gumbel distribution latent node.
"""

import numpy as np
import torch

from .node import CausalNode
from .sampling import uniform, gumbel


class LatentNode(CausalNode):
    """Abstract latent causal node.

    Used for defining exogenous noise signals or confounding latent nodes.

    Any class that inherits from LatentNode needs to override:
    ```python
        def sample(self, n, *parents):
            # samples from the node's distribution.
            ...

        def nll(self, y, **kwargs): 
            # computes the nll of the resulting y.
            # Ignore **kwargs.
            ...
    ```

    Additionally, it should define the class attribute `discrete`, 
    which determines if the latent distribution is discrete.
    """

    latent = True

    def __init__(self, *args, **kwargs):
        assert kwargs.pop('latent', True), self

        super().__init__(*args, latent=True, **kwargs)


    # Overrides:
    def _ex_nodes(self):
        return

    def _ex_invertible(self):
        return True # it has no ex_noise

    def abduct(self, y, *parents): 
        # Should never be called
        raise NotImplementedError()


    # To override:
    def sample(self, n):
        """Sample n rows from the node's distribution and send to device."""
        raise NotImplementedError()

    def nll(self, y, **kwargs):
        """Compute the nll of y."""
        raise NotImplementedError()


class LatentUniform(LatentNode):
    """LatentNode defined by a U(a, b) distribution"""

    discrete = False

    def __init__(self, *args, a=0., b=1., eps=1e-6, **kwargs):
        super().__init__(*args, **kwargs)

        assert a < b, (self, a, b)
        self.a = a
        self.b = b

        self.eps = eps

    def sample(self, n):
        a, b = self.a, self.b
        
        u = uniform(n, self.dim, eps=self.eps, device=self.device)
        return u * (b - a) + a

    def nll(self, y, **kwargs):
        return torch.zeros_like(y[:, 0], device=y.device)


class LatentNormal(LatentNode):
    """LatentNode defined by a N(0, Id) distribution"""

    discrete = False

    def sample(self, n):
        return torch.randn(n, self.dim, device=self.device)

    def nll(self, y, **kwargs):
        return .5 * (self.dim * np.log(2 * np.pi) + (y ** 2).sum(dim=1))


class LatentGumbel(LatentNode):
    """LatentNode defined by a Gumbel(0, 1) distribution"""

    discrete = False

    def sample(self, n):
        return gumbel(n, self.dim, device=self.device)

    def nll(self, y, **kwargs):
        return y + torch.exp(-y)
