"""Includes an abstract class for `CausalNode`.
"""

import torch
from torch import nn


class CausalNode(nn.Module):
    """Base class for a CausalNode.

    Implements basic functionality for any descendant class
    and defines the required attributes and methods to implement.

    Any inheriting class must implement the following methods:
    ```python
        def _ex_nodes(self):
            # Create and return exogenous noise nodes
            ...

        def _ex_invertible(self):
            # Return whether this node can invert ex_noise exactly
            ...

        def warm_start(self, x):
            # Warm starts the node with some values x. 
            # Optional, default doesn't do anything.
            return self # default behaviour
        
        def sample(self, n, *parents):
            # Create n samples of this node's distribution, given parent values
            ...

        def nll(self, y, *parents):
            # Compute the Negative Log-Likelihood of samples y, given parents.
            ...

        def abduct(self, y, *parents):
            # Abduct ex_noise from y and parents.
            ...
    ```

    and define class attributes:
        - latent (bool): whether the node is latent.
        - discrete (bool): whether the corresponding r.v. is discrete.
    """

    latent = None
    """Whether this node class is latent."""
    discrete = None
    """Whether this node class represents a discrete random variable."""

    @property
    def trainable(self):
        """Whether this node class is trainable."""

        # If a child class has set its trainable attribute, we take that value.
        # Otherwise, being trainable means having any trainable parameter.
        if not hasattr(self, '_trainable'):
            self._trainable = None

        if self._trainable is None:
            return any(p.numel() for p in self.parameters())
        else:
            return self._trainable

    @trainable.setter
    def trainable(self, value):
        self._trainable = value


    def __init__(self, name, *parents, dim=1, **kwargs):
        """
        Args:
            name (str): name of the node.
            *parents (CausalNode): nodes that act as parents for this node.
            dim (int): dimensionality of the r.v. described by this node.

        Note that any remaining **kwargs are ignored,
        so that one can pass the same kwargs to all nodes,
        even those that don't require some of them."""

        super().__init__() # first call Module init

        # Set basic attributes and asserts
        assert isinstance(name, str) and name, self
        self.name = name
        
        assert isinstance(dim, int) and dim >= 1, (self, dim)
        self.dim = dim

        assert isinstance(self.discrete, bool), \
            f'Subclasses of CausalNode must define attribute discrete: {self}'
        assert isinstance(self.latent, bool), \
            f'Subclasses of CausalNode must define attribute latent: {self}'

        # Note that parents is a tuple, so they won't be saved as submodules.
        # This is important to avoid calling .to(device) repeatedly.
        # The graph will store all the visible nodes, 
        # no need for the nodes to do so.
        self.parents = parents
        
        # Save ex_nodes. In this case, we do require a ModuleList,
        # since only their corresponding nodes will store them.
        ex = self._ex_nodes()
        if ex is None:
            ex = []
        elif not any(isinstance(ex, t) for t in [list, tuple, set]):
            ex = [ex]

        assert all(not e.parents for e in ex), \
            f'All ex nodes must be parentless: {name}'
        assert len(set(e.name for e in ex)) == len(ex), \
            f'ex_noise had not unique names: {name}'

        self.ex_noise = nn.ModuleList(ex)
        self._parents = parents + tuple(ex) # parents with ex included

        self.device = torch.device('cpu') # start initialized with cpu


    # To override:
    def _ex_nodes(self):
        """Create exogenous noise nodes."""
        raise NotImplementedError()

    def _ex_invertible(self):
        """Whether ex_noise can be inverted from y and parents.

        This is required for counterfactual estimation.
        """
        raise NotImplementedError()

    def warm_start(self, x):
        """Warm start the node with some values x."""
        return self # default behaviour

    def sample(self, n, *parents):
        """Sample from this node's r.v., conditioned on its parents.

        Args:
            n (int): number of instances to sample.
            *parents (torch.Tensor): parents values.
        """
        raise NotImplementedError()

    def nll(self, y, *parents):
        """Negative Log-Likelihood of tensor y conditioned on its parents.

        Args:
            y (torch.Tensor): observable values for the node.
            *parents (torch.Tensor): parent values.
        """
        raise NotImplementedError()

    def abduct(self, y, *parents):
        """Sample ex_noise conditioned on y and its parents.

        Args:
            y (torch.Tensor): observable values for the node.
            *parents (torch.Tensor): parent values.
        """
        raise NotImplementedError()


    # Utilities
    def _process_parents(self, n, *parents):
        """Process all incoming parents to fulfill the requirements.

        Checks that all passed parents have appropriate shape 
        and broadcasts samples if required +
        (n > p.size(0)).

        Also samples from self.ex if not present in *parents and returns them.
        """

        # Check that all parents are passed
        assert len(parents) >= len(self.parents) and \
            all(p is not None for p in parents[:len(self.parents)]), \
            f'Not all parents specified: {self}'

        # Check that they are tensors with the appropriate shape
        assert all(
            p is None or (
                isinstance(p, torch.Tensor) and 
                len(p.shape) == 2 and 
                not n % p.size(0) and 
                p.size(1) == p_node.dim
            )

            for p, p_node in zip(parents, self._parents)
        ),  f'Incorrect parents shape: {self} ' + str({ 
                p.name: tuple(t.shape) 
                for p, t in zip(self._parents, parents) 
            })

        # Broadcast all tensors
        parents = list(
            p.repeat(n // p.size(0), 1) if p is not None else p 
            for p in parents
        )

        # Sample from ex_noise if required
        for i, ex in enumerate(self.ex_noise, len(self.parents)):
            if len(parents) <= i or parents[i] is None:
                sample = ex.sample(n)

                if i < len(parents):
                    parents[i] = sample
                else:
                    parents.append(sample)

        return tuple(parents)


    # Utils
    @property
    def depth(self):
        # Returns topological order depth. 
        # Note that this requires the graph to be acyclic.
        if not self.parents:
            return 0
        else:
            return max(parent.depth for parent in self.parents) + 1


    # Magic methods
    def __hash__(self):
        return hash(self.name)

    def __repr__(self):
        if hasattr(self, 'name'):
            return f'<{self.__class__.__name__}: {self.name}>'
        else:
            # Non-initialized node (yet)
            return '<{self.__class__.__name__}>'

    def __lt__(self, other):
        return self.name < other.name # alphabetical order

    def __iter__(self):
        """Yield all its ex_noises and self. 
        
        Used to get the topological ordering of ALL nodes in a graph,
        if each node's __iter__ is called in topological ordering.

        Example:
        for node in topological_ordering(graph.nodes):
            for subnode in node:
                yield subnode
        """

        for ex in self.ex_noise:
            yield ex

        yield self


    # Device methods
    # We override them to save the corresponding device 
    def _update_device(self, device):
        self.device = device

        for node in self:
            if node is not self:
                node._update_device(device)

    def to(self, device):
        """Update each component device, including attribute `device`."""
        self._update_device(device)

        return super().to(device)

    def cpu(self):
        return self.to(torch.device('cpu'))

    def cuda(self):
        return self.to(torch.device('cuda'))