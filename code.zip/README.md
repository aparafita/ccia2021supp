# Deep Causal Graphs: a One-Fits-All Framework for Causal Estimation

This zip folder includes all code required for the execution of the experiments in the paper.

## Data

The IHDP and Jobs datasets are included in this zip file. They can also be downloaded; the download link can be found in experiments/data/README.md file. As for the salary dataset, since it is synthetic, we include both its samples and its creation code in its corresponding folder: experiments/data/salary.

## Requirements

We include two Python libraries required for the execution of the experiments: flow and dcg.
Each one has its own set of requirements. Preferably use a virtual environment before installing.

```setup
cd flow
pip install -r requirements.txt
pip install -e .
cd ../dcg
pip install -r requirements.txt
pip install -e .
```

After this setup, we include all experiments showcased in the paper in the experiments/ folder.

## Pre-trained Models

We do not include all pretrained models, since their compressed size is over a GB of data (there is a different model for each replication (1000 in IHDP, 10 in Jobs), with 10 cross-validation models each). We include, however, the trained graph for salary (models/salary.pt) so that notebooks/Applications.ipynb can be tested. Note that this graph, since it contains many more nodes and uses a very permissive patience value (100 epochs before early stopping), can take up to half an hour to train, which is why we include it pretrained. For the rest of the models, scripts are included to run their training (scripts/run_ihdp.sh, scripts/run_jobs.sh). 

## Training

While in the experiments/ folder:

* Execute each sh script for training that dataset. In particular:

```train
sh scripts/run_ihdp.sh
sh scripts/run_jobs.sh
```

Everything will be stored in the models/ and results/ folder.

Each graph takes less than half a minute to train in a home computer with a NVIDIA GeForce GTX 1080. However, the total amount of graphs to train makes these executions to last around 3 and a half days (if all are run sequentially).

For the Applications graph (salary dataset), its training code is included in the Applications.ipynb notebook, and will be run automatically if models/salary.pt does not exist.

## Evaluation

After training each model, you can use the scripts/aggregate_results.py script to aggregate all metrics. Additionally, we include a notebook in notebooks/ with which to run the applications showcased in the paper.

## Contributing

Both software libraries will be open-sourced after review. Links are omitted due to double-blind review.